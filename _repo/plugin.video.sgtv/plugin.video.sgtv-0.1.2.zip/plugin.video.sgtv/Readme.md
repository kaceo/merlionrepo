# Singapore SG TV kodi plugin

For learning about Kodi internals, the addon is for
experimental use only.  


SG-Singapore TV streaming services

* mediacorp ch5
* mediacorp ch8
* mediacorp chU
* mediacorp Channel News Asia
* mediacorp Okto

Other stations

License: [GPL v.3](http://www.gnu.org/copyleft/gpl.html)
